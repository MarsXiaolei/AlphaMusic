﻿#include "WidgetLocalMusic.h"
#include "Module/Global.h"

WidgetLocalMusic::WidgetLocalMusic(QWidget *parent) : QWidget(parent)
{
    QGridLayout *gridLayout = new QGridLayout(this);
    gridLayout->setSpacing(6);
    gridLayout->setContentsMargins(0, 0, 0, 0);

    QHBoxLayout *horizontalLayout_2 = new QHBoxLayout();
    //horizontalLayout_2->setSpacing(SPACE);
    horizontalLayout_2->setContentsMargins(SPACE, SPACE/2, SPACE, 0);

    QLabel *labelLocal = new QLabel(this);
    labelLocal->setText("本地音乐");
    labelLocal->setStyleSheet("QLabel{font-family:Microsoft YaHei;font-size: 18pt;color: #333333;/*background-color: #2E3648;*}");
    horizontalLayout_2->addWidget(labelLocal);
    gridLayout->addLayout(horizontalLayout_2, 0, 0, 1, 1);

    QLabel *label_1 = new QLabel(this);
    label_1->setText("歌曲");

    QLabel *label_2 = new QLabel(this);
    label_2->setText("歌手");

    QLabel *label_3 = new QLabel(this);
    label_3->setText("专辑");

    QLabel *label_4 = new QLabel(this);
    label_4->setText("大小");
    QString labelStyle = "QLabel{font-family:Microsoft YaHei;font-size: 10pt;color: #666666;/*background-color: #2E3648;*}";
    label_1->setStyleSheet(labelStyle);
    label_2->setStyleSheet(labelStyle);
    label_3->setStyleSheet(labelStyle);
    label_4->setStyleSheet(labelStyle);

    QHBoxLayout *horizontalLayout = new QHBoxLayout();
    //horizontalLayout->setSpacing(SPACE);
    horizontalLayout->setContentsMargins(SPACE, SPACE/2, SPACE, 0);

    horizontalLayout->addWidget(label_1);
    horizontalLayout->addWidget(label_2);
    horizontalLayout->addWidget(label_3);
    horizontalLayout->addWidget(label_4);
    gridLayout->addLayout(horizontalLayout, 1, 0, 1, 1);

    QListWidget *listWidget = new QListWidget(this);
    //listWidget->setGeometry(QRect(0, 0, 972, 615));
    listWidget->setViewMode(QListView::ListMode);
    listWidget->setFrameShape(QListWidget::NoFrame);
    listWidget->setSpacing(0);
    listWidget->setMovement(QListWidget::Static);

//    listWidget->setSelectionMode(QAbstractItemView::NoSelection);
//    listWidget->setFocusPolicy(Qt::NoFocus);

//    listWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

//    listWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
//    listWidget->setVerticalScrollMode(QListWidget::ScrollPerPixel);
//    listWidget->verticalScrollBar()->setSingleStep(10);
//    listWidget->verticalScrollBar()->setStyleSheet("QScrollBar:vertical{background:rgb(255,255,255); color:rgb(200,200,200);width:6px;border:1px solid transparent;border-radius:2px;padding-top:0px;padding-bottom:0px;}"
//                                                      "QScrollBar::handle:vertical{background:rgb(198,198,198);width:4px;border:1px solid transparent;border-radius:2px;}"
//                                                      "QScrollBar::add-line:vertical{subcontrol-position:bottom;width:0px;height:0px;}"
//                                                      "QScrollBar::sub-line:vertical{subcontrol-position:top;width:0px;height:0px;}"
//                                                      "QScrollBar::add-page:vertical{background:transparent;width:0px;}"
//                                                      "QScrollBar::sub-page:vertical{background:transparent;width:0px;}");

    MyListItem *widget = new MyListItem(listWidget);

    QListWidgetItem *items = new QListWidgetItem(listWidget);
    QSize size = items->sizeHint();
    items->setSizeHint(QSize(size.width(), 45));
    widget->show();
    listWidget->addItem(items);
    listWidget->setItemWidget(items, widget);

    MyListItem *widget_2 = new MyListItem(listWidget);
    QListWidgetItem *items_2 = new QListWidgetItem(listWidget);
    size = items_2->sizeHint();
    items_2->setSizeHint(QSize(size.width(), 45));
    widget->show();
    listWidget->addItem(items_2);
    listWidget->setItemWidget(items_2, widget_2);

    gridLayout->addWidget(listWidget, 2, 0, 1, 1);
}
