﻿#include "MainInterface.h"
#include "ui_MainInterface.h"

#include <QDebug>
#include "Module/Global.h"

MainInterface::MainInterface(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainInterface)
{
    ui->setupUi(this);

    m_factorx = 1.0;  //1920 是开发电脑界面的分辨率
    m_factory = 1.0;
    QScreen * screen =  QGuiApplication::primaryScreen();
    QRect rect = screen->geometry();
    int desktop_width = rect.width();
    int desktop_height = rect.height();
    qDebug() << desktop_width <<desktop_height;

    //计算横向纵向坐标的伸缩系统
    m_factorx = desktop_width / 1920.0;  //1920 是开发电脑界面的分辨率
    m_factory = desktop_height / 1080.0;
    if((int)m_factorx != 1 || (int)m_factory != 1){
        this->resize(WINDOW_W * m_factorx, WINDOW_H * m_factory);
    }
    else{
        this->resize(WINDOW_W, WINDOW_H);
        this->setMinimumSize(WINDOW_W, WINDOW_H);
    }

    m_fullScreenFlag = 0;

    m_timer = new QTimer(this);
    connect(m_timer, &QTimer::timeout, this, &MainInterface::checkScreenSlot);
    m_timer->start(1000);

    //设置窗口无边框
    setWindowFlags(Qt::FramelessWindowHint);
    //设置窗体透明,防止边距显示不同的颜色
    setAttribute(Qt::WA_TranslucentBackground, true);
    //setWindowModality(Qt::ApplicationModal);//设置窗体模态，要求该窗体没有父类，否则无效

    //为了实现鼠标的位置信息获取不受子控件的影响，启动鼠标悬浮追踪
    setAttribute(Qt::WA_Hover);

    setMouseTracking(true);

    //实例阴影shadow（注意：设置无边框后，需要给阴影绘制预留尺寸，不能完全填充）
    QGraphicsDropShadowEffect *shadow = new QGraphicsDropShadowEffect(this);
    shadow->setOffset(0, 0);
    //边框阴影颜色最好和背景色一样，容易产生渐变
    shadow->setColor("#2f89fc");
    shadow->setBlurRadius(SHADOW);
    setGraphicsEffect(shadow);

    //主窗口使用网格布局
    QGridLayout *gridLayout;
    QSpacerItem *verticalSpacer;
    QSpacerItem *horizontalSpacer;

    gridLayout = new QGridLayout(this);
    gridLayout->setSpacing(6);
    gridLayout->setContentsMargins(SHADOW, SHADOW, SHADOW + SPACE, SHADOW);
    gridLayout->setObjectName(QString::fromUtf8("gridLayout"));

    //////////////水平布局//////////////////
    QHBoxLayout *horizontalLayout;
    horizontalLayout = new QHBoxLayout();
    horizontalLayout->setSpacing(12);
    horizontalLayout->setContentsMargins(210 + PB_W, (TITLE_H - PB_H)/2, 0, (TITLE_H - PB_H)/2);
    horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));

    //搜索框
    m_pbSerach = new QPushButton(this);
    m_pbSerach->setCursor(Qt::PointingHandCursor);
    m_pbSerach->setFixedSize(PB_W_2, PB_H_2);
    m_pbSerach->setToolTip("搜索");
    m_pbSerach->setStyleSheet("QPushButton{border-image:url(:/Images/search_line.png); background:transparent;} \
                              QPushButton:hover{border-image:url(:/Images/search_line_2.png)} \
                              QPushButton:pressed{border-image:url(:/Images/search_line_2.png)}");
    connect(m_pbSerach, &QPushButton::clicked, this, &MainInterface::serachSlot);

    //防止文本框输入内容位于按钮之下
    m_leSerach = new QLineEdit;
    QMargins margins = m_leSerach->textMargins();
    m_leSerach->setTextMargins(margins.left(), margins.top() + SPACE/3, m_pbSerach->width(), margins.bottom() + SPACE/3);
    m_leSerach->setPlaceholderText("搜索音乐");
    m_leSerach->setStyleSheet(g_styleSheet);

    QHBoxLayout *searchLayout = new QHBoxLayout();
    searchLayout->addStretch();
    searchLayout->addWidget(m_pbSerach);
    searchLayout->setSpacing(0);
    searchLayout->setContentsMargins(0, 0, 6, 0);
    m_leSerach->setLayout(searchLayout);

    horizontalLayout->addWidget(m_leSerach);

    horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
    horizontalLayout->addItem(horizontalSpacer);

    m_pbClose = new QPushButton(this);
    m_pbClose->setFocusPolicy(Qt::NoFocus);
    //m_pbClose->setGeometry(QRect(WINDOW_W - SHADOW - (SPACE + PB_W), (TITLE_H - PB_H)/2 + SHADOW, PB_W, PB_H));
    m_pbClose->setStyleSheet("QPushButton{border-image:url(:/Images/close_line.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/close_line_3.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    connect(m_pbClose, &QPushButton::clicked, this, &MainInterface::closeSlot);
    m_pbClose->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbClose->setMaximumSize(QSize(PB_W_2, PB_H_2));


    m_pbMaximize = new QPushButton(this);
    m_pbMaximize->setFocusPolicy(Qt::NoFocus);
    //m_pbMaximize->setGeometry(QRect(WINDOW_W - SHADOW - 2*(SPACE + PB_W), (TITLE_H - PB_H)/2 + SHADOW, PB_W, PB_H));
    m_pbMaximize->setStyleSheet("QPushButton{border-image:url(:/Images/fullscreen_line.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/fullscreen_line_3.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    connect(m_pbMaximize, &QPushButton::clicked, this, &MainInterface::maximizeSlot);
    m_pbMaximize->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbMaximize->setMaximumSize(QSize(PB_W_2, PB_H_2));

    m_pbMinimize = new QPushButton(this);
    m_pbMinimize->setFocusPolicy(Qt::NoFocus);
    //m_pbMinimize->setGeometry(QRect(WINDOW_W - SHADOW - 3*(SPACE + PB_W), (TITLE_H - PB_H)/2 + SHADOW, PB_W, PB_H));
    m_pbMinimize->setStyleSheet("QPushButton{border-image:url(:/Images/subtract_line.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/subtract_line_2.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    connect(m_pbMinimize, &QPushButton::clicked, this, &MainInterface::minimizeSlot);
    m_pbMinimize->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbMinimize->setMaximumSize(QSize(PB_W_2, PB_H_2));

    m_pbSkin = new QPushButton(this);
    m_pbSkin->setFocusPolicy(Qt::NoFocus);
    //m_pbSkin->setGeometry(QRect(WINDOW_W - SHADOW - 3*(SPACE + PB_W), (TITLE_H - PB_H)/2 + SHADOW, PB_W, PB_H));
    m_pbSkin->setStyleSheet("QPushButton{border-image:url(:/Images/t_shirt_fill.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/t_shirt_fill_1.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    connect(m_pbSkin, &QPushButton::clicked, this, &MainInterface::minimizeSlot);
    m_pbSkin->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbSkin->setMaximumSize(QSize(PB_W_2, PB_H_2));

    m_pbMainMenu = new QPushButton(this);
    m_pbMainMenu->setFocusPolicy(Qt::NoFocus);
    //m_pbMainMenu->setGeometry(QRect(WINDOW_W - SHADOW - 3*(SPACE + PB_W), (TITLE_H - PB_H)/2 + SHADOW, PB_W, PB_H));
    m_pbMainMenu->setStyleSheet("QPushButton{border-image:url(:/Images/list_settings_line.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/list_settings_line_2.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    connect(m_pbMainMenu, &QPushButton::clicked, this, &MainInterface::minimizeSlot);
    m_pbMainMenu->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbMainMenu->setMaximumSize(QSize(PB_W_2, PB_H_2));

    horizontalLayout->addWidget(m_pbMainMenu);
    horizontalLayout->addWidget(m_pbSkin);
    horizontalLayout->addWidget(m_pbMinimize);
    horizontalLayout->addWidget(m_pbMaximize);
    horizontalLayout->addWidget(m_pbClose);
    gridLayout->addLayout(horizontalLayout, 0, 0, 1, 2);

#if 1
    //////////////水平布局//////////////////
    QHBoxLayout *horizontalLayout_2;
    horizontalLayout_2 = new QHBoxLayout();
    horizontalLayout_2->setSpacing(SPACE);
    horizontalLayout_2->setContentsMargins(PB_W, (TITLE_H - PB_H - 20)/2, PB_W, (TITLE_H - PB_H - 20)/2);
    horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));

    m_labelMusicPoster = new QLabel(this);
    m_labelMusicPoster->setPixmap(QPixmap(":/Images/yinyangshi_ali.jpg"));
    //m_labelMusicPoster->setText("在线音乐");
    m_labelMusicPoster->setMinimumSize(QSize(50, 50));
    m_labelMusicPoster->setMaximumSize(QSize(50, 50));
    //m_labelMusicPoster->setStyleSheet(g_styleSheet);

    QVBoxLayout *verticalLayout_2;
    verticalLayout_2 = new QVBoxLayout();
    verticalLayout_2->setSpacing(6);
    //verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout"));
    verticalLayout_2->setContentsMargins(0, 0, 0, 0);

    QHBoxLayout *horizontalLayout_3;
    horizontalLayout_3 = new QHBoxLayout();
    horizontalLayout_3->setSpacing(SPACE);
    horizontalLayout_3->setContentsMargins(0, 0, 200 - SPACE - 2*PB_W_2, 0);
    //horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_2"));

    m_labelMusicName = new QLabel(this);
    //m_labelMusicName->setPixmap(QPixmap(":/Images/yinyangshi_ali.jpg"));
    m_labelMusicName->setText("在线音乐-往事随风");
    m_labelMusicName->setMinimumSize(QSize(120, PB_H_2));
    m_labelMusicName->setMaximumSize(QSize(120, PB_H_2));
    m_labelMusicName->setStyleSheet(g_styleSheet);

    //添加到我喜欢
    m_pbAddFavorite = new QPushButton(this);
    m_pbAddFavorite->setFocusPolicy(Qt::NoFocus);
    //m_pbAddFavorite->setGeometry(QRect(WINDOW_W/2 - SHADOW - 4*(SPACE + PB_W), WINDOW_H - SHADOW- PB_H - SPACE, PB_W, PB_H));
    m_pbAddFavorite->setStyleSheet("QPushButton{border-image:url(:/Images/heart_add_fill.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/heart_add_fill_2.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    connect(m_pbAddFavorite, &QPushButton::clicked, this, &MainInterface::playModeSlot);
    m_pbAddFavorite->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbAddFavorite->setMaximumSize(QSize(PB_W_2, PB_H_2));

    //下载
    m_pbDownload = new QPushButton(this);
    m_pbDownload->setFocusPolicy(Qt::NoFocus);
    //m_pbDownload->setGeometry(QRect(WINDOW_W/2 - SHADOW - 4*(SPACE + PB_W), WINDOW_H - SHADOW- PB_H - SPACE, PB_W, PB_H));
    m_pbDownload->setStyleSheet("QPushButton{border-image:url(:/Images/download_2_fill.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/download_2_fill_2.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    connect(m_pbDownload, &QPushButton::clicked, this, &MainInterface::playModeSlot);
    m_pbDownload->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbDownload->setMaximumSize(QSize(PB_W_2, PB_H_2));

    horizontalLayout_3->addWidget(m_pbAddFavorite);
    horizontalLayout_3->addWidget(m_pbDownload);

    verticalLayout_2->addWidget(m_labelMusicName);
    verticalLayout_2->addLayout(horizontalLayout_3);

    horizontalLayout_2->addWidget(m_labelMusicPoster);
    horizontalLayout_2->addLayout(verticalLayout_2);

    QSpacerItem *horizontalSpacer_2;
    horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
    horizontalLayout_2->addItem(horizontalSpacer_2);

    //下一曲
    m_pbNext = new QPushButton(this);
    m_pbNext->setFocusPolicy(Qt::NoFocus);
    //m_pbNext->setGeometry(QRect(WINDOW_W/2 - SHADOW - 1*(SPACE + PB_W), WINDOW_H - SHADOW- PB_H - SPACE, PB_W, PB_H));
    m_pbNext->setStyleSheet("QPushButton{border-image:url(:/Images/skip_forward_fill.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/skip_forward_fill_2.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    connect(m_pbNext, &QPushButton::clicked, this, &MainInterface::nextSlot);
    m_pbNext->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbNext->setMaximumSize(QSize(PB_W_2, PB_H_2));

    //播放和暂停
    m_pbPlay = new QPushButton(this);
    m_pbPlay->setFocusPolicy(Qt::NoFocus);
    //m_pbPlay->setGeometry(QRect(WINDOW_W/2 - SHADOW - 2*(SPACE + PB_W), WINDOW_H - SHADOW- PB_H - SPACE, PB_W, PB_H));
    m_pbPlay->setStyleSheet("QPushButton{border-image:url(:/Images/play_circle_fill.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    connect(m_pbPlay, &QPushButton::clicked, this, &MainInterface::playSlot);
    m_playState = Pause;
    m_pbPlay->setMinimumSize(QSize(PB_W, PB_H));
    m_pbPlay->setMaximumSize(QSize(PB_W, PB_H));

    //上一曲
    m_pbPrevious = new QPushButton(this);
    m_pbPrevious->setFocusPolicy(Qt::NoFocus);
    //m_pbPrevious->setGeometry(QRect(WINDOW_W/2 - SHADOW - 3*(SPACE + PB_W), WINDOW_H - SHADOW- PB_H - SPACE, PB_W, PB_H));
    m_pbPrevious->setStyleSheet("QPushButton{border-image:url(:/Images/skip_back_fill.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/skip_back_fill_3.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    connect(m_pbPrevious, &QPushButton::clicked, this, &MainInterface::previousSlot);
    m_pbPrevious->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbPrevious->setMaximumSize(QSize(PB_W_2, PB_H_2));

    //播放模式
    m_pbPlayMode = new QPushButton(this);
    m_pbPlayMode->setFocusPolicy(Qt::NoFocus);
    //m_pbPlayMode->setGeometry(QRect(WINDOW_W/2 - SHADOW - 4*(SPACE + PB_W), WINDOW_H - SHADOW- PB_H - SPACE, PB_W, PB_H));
    m_pbPlayMode->setStyleSheet("QPushButton{border-image:url(:/Images/repeat_2_line.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/repeat_2_line_2.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    connect(m_pbPlayMode, &QPushButton::clicked, this, &MainInterface::playModeSlot);
    m_pbPlayMode->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbPlayMode->setMaximumSize(QSize(PB_W_2, PB_H_2));

    //音量
    m_pbVolume = new QPushButton(this);
    m_pbVolume->setFocusPolicy(Qt::NoFocus);
    //m_pbVolume->setGeometry(QRect(WINDOW_W/2 - SHADOW - 4*(SPACE + PB_W), WINDOW_H - SHADOW- PB_H - SPACE, PB_W, PB_H));
    m_pbVolume->setStyleSheet("QPushButton{border-image:url(:/Images/volume_up_fill.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/volume_up_fill_3.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    connect(m_pbVolume, &QPushButton::clicked, this, &MainInterface::setVolumeSlot);
    m_pbVolume->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbVolume->setMaximumSize(QSize(PB_W_2, PB_H_2));

    //播放时间
    m_labelPlayTime = new QLabel(this);
    m_playTime = "03:35 / 03:46";
    m_labelPlayTime->setText(m_playTime);
    m_labelPlayTime->setMinimumSize(QSize(85, 30));
    m_labelPlayTime->setMaximumSize(QSize(85, 30));
    m_labelPlayTime->setStyleSheet(g_styleSheet);

    //歌词
    m_pbLyrics = new QPushButton(this);
    m_pbLyrics->setText("词");
    m_pbLyrics->setStyleSheet(g_styleSheet);
    m_pbLyrics->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbLyrics->setMaximumSize(QSize(PB_W_2, PB_H_2));

    m_pbPlayQueue = new QPushButton(this);
    m_pbPlayQueue->setFocusPolicy(Qt::NoFocus);
    //m_pbPlayQueue->setGeometry(QRect(WINDOW_W/2 - SHADOW - 4*(SPACE + PB_W), WINDOW_H - SHADOW- PB_H - SPACE, PB_W, PB_H));
    m_pbPlayQueue->setStyleSheet("QPushButton{border-image:url(:/Images/play_list_fill.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/play_list_fill_1.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    connect(m_pbPlayQueue, &QPushButton::clicked, this, &MainInterface::playModeSlot);
    m_pbPlayQueue->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbPlayQueue->setMaximumSize(QSize(PB_W_2, PB_H_2));

    horizontalLayout_2->addWidget(m_pbPlayMode);
    horizontalLayout_2->addWidget(m_pbPrevious);
    horizontalLayout_2->addWidget(m_pbPlay);
    horizontalLayout_2->addWidget(m_pbNext);
    horizontalLayout_2->addWidget(m_pbVolume);

    QSpacerItem *horizontalSpacer_3;
    horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
    horizontalLayout_2->addItem(horizontalSpacer_3);

    horizontalLayout_2->addWidget(m_labelPlayTime);
    horizontalLayout_2->addWidget(m_pbLyrics);
    horizontalLayout_2->addWidget(m_pbPlayQueue);

    gridLayout->addLayout(horizontalLayout_2, 3, 1, 1, 1);

    /**************垂直布局***************/
    QVBoxLayout *verticalLayout;
    verticalLayout = new QVBoxLayout();
    verticalLayout->setSpacing(6);
    verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
    verticalLayout->setContentsMargins((210 - PB_W_3)/2, 0, (210 - PB_W_3)/2, 0);

    QLabel *m_labelOnlineMusic = new QLabel(this);
    m_labelOnlineMusic->setText("在线音乐");
    m_labelOnlineMusic->setMinimumSize(QSize(PB_W_3, 30));
    m_labelOnlineMusic->setMaximumSize(QSize(PB_W_3, 30));
    m_labelOnlineMusic->setStyleSheet(g_styleSheet);

    QPushButton *m_onlineMusic_1 = new QPushButton(this);
    m_onlineMusic_1->setText("推荐");
    m_onlineMusic_1->setStyleSheet(g_styleSheet);
    QPushButton *m_onlineMusic_2 = new QPushButton(this);
    m_onlineMusic_2->setText("音乐馆");
    m_onlineMusic_2->setStyleSheet(g_styleSheet);
    QPushButton *m_onlineMusic_3 = new QPushButton(this);
    m_onlineMusic_3->setText("视频");
    m_onlineMusic_3->setStyleSheet(g_styleSheet);
    QPushButton *m_onlineMusic_4 = new QPushButton(this);
    m_onlineMusic_4->setText("电台");
    m_onlineMusic_4->setStyleSheet(g_styleSheet);

    m_onlineMusic_1->setMinimumSize(QSize(PB_W_3, PB_H_3));
    m_onlineMusic_1->setMaximumSize(QSize(PB_W_3, PB_H_3));

    m_onlineMusic_2->setMinimumSize(QSize(PB_W_3, PB_H_3));
    m_onlineMusic_2->setMaximumSize(QSize(PB_W_3, PB_H_3));

    m_onlineMusic_3->setMinimumSize(QSize(PB_W_3, PB_H_3));
    m_onlineMusic_3->setMaximumSize(QSize(PB_W_3, PB_H_3));

    m_onlineMusic_4->setMinimumSize(QSize(PB_W_3, PB_H_3));
    m_onlineMusic_4->setMaximumSize(QSize(PB_W_3, PB_H_3));

    verticalLayout->addWidget(m_labelOnlineMusic);
    verticalLayout->addWidget(m_onlineMusic_1);
    verticalLayout->addWidget(m_onlineMusic_2);
    verticalLayout->addWidget(m_onlineMusic_3);
    verticalLayout->addWidget(m_onlineMusic_4);

    QSpacerItem *verticalSpacer_3;
    verticalSpacer_3 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);
    verticalLayout->addItem(verticalSpacer_3);

    QLabel *m_labelMyMusic = new QLabel(this);
    m_labelMyMusic->setText("我的音乐");
    m_labelMyMusic->setMinimumSize(QSize(PB_W_3, PB_H_3));
    m_labelMyMusic->setMaximumSize(QSize(PB_W_3, PB_H_3));
    m_labelMyMusic->setStyleSheet(g_styleSheet);

    QPushButton *m_localMusic_1 = new QPushButton(this);
    m_localMusic_1->setText("我喜欢");
    m_localMusic_1->setStyleSheet(g_styleSheet);
    connect(m_localMusic_1, &QPushButton::clicked, this, &MainInterface::favoriteSlot);
    QPushButton *m_localMusic_2 = new QPushButton(this);
    m_localMusic_2->setText("本地和下载");
    m_localMusic_2->setStyleSheet(g_styleSheet);
    connect(m_localMusic_2, &QPushButton::clicked, this, &MainInterface::localMusicSlot);
    QPushButton *m_localMusic_3 = new QPushButton(this);
    m_localMusic_3->setText("最近播放");
    m_localMusic_3->setStyleSheet(g_styleSheet);
    connect(m_localMusic_3, &QPushButton::clicked, this, &MainInterface::recentPlaySLot);
    QPushButton *m_localMusic_4 = new QPushButton(this);
    m_localMusic_4->setText("试听列表");
    m_localMusic_4->setStyleSheet(g_styleSheet);

    m_localMusic_1->setMinimumSize(QSize(PB_W_3, PB_H_3));
    m_localMusic_1->setMaximumSize(QSize(PB_W_3, PB_H_3));

    m_localMusic_2->setMinimumSize(QSize(PB_W_3, PB_H_3));
    m_localMusic_2->setMaximumSize(QSize(PB_W_3, PB_H_3));

    m_localMusic_3->setMinimumSize(QSize(PB_W_3, PB_H_3));
    m_localMusic_3->setMaximumSize(QSize(PB_W_3, PB_H_3));

    m_localMusic_4->setMinimumSize(QSize(PB_W_3, PB_H_3));
    m_localMusic_4->setMaximumSize(QSize(PB_W_3, PB_H_3));

    verticalLayout->addWidget(m_labelMyMusic);
    verticalLayout->addWidget(m_localMusic_1);
    verticalLayout->addWidget(m_localMusic_2);
    verticalLayout->addWidget(m_localMusic_3);
    verticalLayout->addWidget(m_localMusic_4);

    QSpacerItem *verticalSpacer_2;
    verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);
    verticalLayout->addItem(verticalSpacer_2);

    gridLayout->addLayout(verticalLayout, 1, 0, 4, 1);

//    verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);
//    gridLayout->addItem(verticalSpacer, 1, 1, 1, 1);

    //播放滑动条
    m_sliderPlay = new QSlider(this);
    m_sliderPlay->setObjectName(QString::fromUtf8("horizontalSlider"));
    m_sliderPlay->setOrientation(Qt::Horizontal);
    m_sliderPlay->setStyleSheet(g_styleSheet);
    gridLayout->addWidget(m_sliderPlay, 2, 1, 1, 1);

    m_stackedWidget = new QStackedWidget(this);
    m_stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
    //m_stackedWidget->setStyleSheet("background-color:#F5F5F5;");
//    page = new QWidget();
//    page->setObjectName(QString::fromUtf8("page"));
//    m_stackedWidget->addWidget(page);
//    page_2 = new QWidget();
//    page_2->setObjectName(QString::fromUtf8("page_2"));
//    m_stackedWidget->addWidget(page_2);
    gridLayout->addWidget(m_stackedWidget, 1, 1, 1, 1);
    WidgetLocalMusic *m_widgetLocalMusic = new WidgetLocalMusic(this);
    m_stackedWidget->addWidget(m_widgetLocalMusic);
#endif


    m_player = new QMediaPlayer(this);//初始化音乐
    m_playlist = new QMediaPlaylist(this);//初始化播放列表
    m_playlist->setPlaybackMode(QMediaPlaylist::Loop);//设置播放模式(顺序播放，单曲循环，随机播放等)

    m_playlist->addMedia(QUrl::fromLocalFile("E:\\AlphaMusic\\Music\\BEYOND - 海阔天空.mp3"));//添加歌曲，这里添加的是歌曲的路径
    m_playlist->addMedia(QUrl::fromLocalFile("E:\\AlphaMusic\\Music\\林俊杰 - 美人鱼.mp3"));//添加歌曲，这里添加的是歌曲的路径
    m_playlist->addMedia(QUrl::fromLocalFile("E:\\AlphaMusic\\Music\\张芸京 - 偏爱.mp3"));//添加歌曲，这里添加的是歌曲的路径
    m_playlist->addMedia(QUrl::fromLocalFile("E:\\AlphaMusic\\Music\\周杰伦 - 蒲公英的约定.mp3"));//添加歌曲，这里添加的是歌曲的路径
    m_playlist->setCurrentIndex(0);

    m_player->setPlaylist(m_playlist);  //设置播放列表
    m_player->stop();

    repaint();
}

MainInterface::~MainInterface()
{
    delete ui;
}

///////////////////// Event //////////////////////
void MainInterface::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QPainter painter(this);

    //绘制背景,需要给边框阴影留空间
    painter.fillRect(QRect(rect().x() + SHADOW, rect().y() + SHADOW, rect().width() - SHADOW * 2, rect().height() - SHADOW * 2), QBrush("#FFFFFF"));

    //painter.fillRect(QRect(200, 200, 640, 480), QBrush("#333333"));

    //绘制标题栏
    //painter.fillRect(QRect(SHADOW + m_factorx*210, SHADOW, rect().width() - SHADOW * 2 - m_factorx*210, m_factory*TITLE_H), QBrush("#2196F3"));

#if 1
    //工具栏
    painter.fillRect(QRect(SHADOW, SHADOW, m_factorx*210, rect().height() - SHADOW * 2), QBrush("#EEEEEE"));

    painter.fillRect(QRect(SHADOW + m_factorx*210, SHADOW, rect().width() - SHADOW * 2 - m_factorx*210, rect().height() - SHADOW * 2), QBrush("#FAFAFA"));

    QImage qqMusicImage(":/Images/QQMusic_2.png");
    painter.drawImage(QRect(SHADOW + m_factorx*(210 - 132)/2, SHADOW + m_factory*(TITLE_H - 44)/2, m_factorx*132, m_factory*44), qqMusicImage);
#endif
}

bool MainInterface::event(QEvent *event)
{
    if (event->type() == QEvent::HoverMove) {
        QHoverEvent *hoverEvent = static_cast<QHoverEvent *>(event);
        QMouseEvent mouseEvent(QEvent::MouseMove, hoverEvent->pos(),
                               Qt::NoButton, Qt::NoButton, Qt::NoModifier);
        mouseMoveEvent(&mouseEvent);
    }

    return QWidget::event(event);
}

//globalPos-鼠标在桌面的位置
//pos-小部件原点在桌面的位置
//mapToGlobal(QPoint(0,0)) ;将当前控件的相对位置转换为屏幕绝对位置
//mapFromGlobal(QPoint(0,0)), 将绝对位置对应到控件的相对位置
//rect()的x()、y()始终从(0,0)起，宽高客户区宽高
//geometry()相对于父窗体的rect区域，当窗体是主窗体时，即是屏幕上的位置，客户区
//frameGeometry()相对于父窗体的rect区域，当窗体是主窗体时，即是屏幕上的位置，客户区 + 标题栏。
void MainInterface::mousePressEvent(QMouseEvent *event)
{
    if((event->button() == Qt::LeftButton)){
        m_mousePress = true;
        m_pressPoint = event->globalPos();   //鼠标在窗口内的位置
    }
    else if(event->button() == Qt::RightButton){
        //如果是右键
        this->close();
    }

    event->accept();
}

void MainInterface::mouseReleaseEvent(QMouseEvent *event)
{
    Q_UNUSED(event);
    m_mousePress = false;
}

void MainInterface::mouseDoubleClickEvent(QMouseEvent *event)
{
    Q_UNUSED(event);
}

void MainInterface::mouseMoveEvent(QMouseEvent *event)
{
    //Q_UNUSED(event);
    //如果当前鼠标坐标在矩形内，则可移动窗口
    if(m_mousePress){
        if(QRect(SHADOW, SHADOW + SPACE/2, rect().width() - 2*SHADOW, TITLE_H + SHADOW - SPACE/2).contains(this->mapFromGlobal(m_pressPoint))){
            move(event->globalPos() - (m_pressPoint - this->pos()));   //窗口左上角点坐标
            m_pressPoint = event->globalPos();
        }
    }

    //注意全屏时，无效
    //鼠标进入特定区域，自动修改形状
    if(QRect(SHADOW, SHADOW + SPACE/2,
             SPACE/2, rect().height() - SPACE - 2*SHADOW).contains(this->mapFromGlobal(event->globalPos()))){
        setCursor(Qt::SizeHorCursor);//left
        m_direction = StretchDirection::Left;
    }
    else if(QRect(rect().width() - SHADOW - SPACE/2, SHADOW + SPACE/2,
                  SPACE/2, rect().height() - SPACE - 2*SHADOW).contains(this->mapFromGlobal(event->globalPos()))){
        setCursor(Qt::SizeHorCursor);//right
        m_direction = StretchDirection::Right;
    }
    else if(QRect(SHADOW + SPACE/2, SHADOW,
                  rect().width() - 2*SHADOW - SPACE, SPACE/2).contains(this->mapFromGlobal(event->globalPos()))){
        setCursor(Qt::SizeVerCursor);//top
        m_direction = StretchDirection::Up;
    }
    else if(QRect(SHADOW + SPACE/2, rect().height() - SHADOW -SPACE/2,
                  rect().width() - 2*SHADOW - SPACE, SPACE/2).contains(this->mapFromGlobal(event->globalPos()))){
        setCursor(Qt::SizeVerCursor);//bottom
        m_direction = StretchDirection::Down;
    }
    else if(QRect(SHADOW, SHADOW,
                  SPACE/2, SPACE/2).contains(this->mapFromGlobal(event->globalPos()))){
        setCursor(Qt::SizeFDiagCursor);//left top
        m_direction = StretchDirection::TopLeft;
    }
    else if(QRect(rect().width() - SHADOW - SPACE/2, SHADOW,
                  SPACE/2, SPACE/2).contains(this->mapFromGlobal(event->globalPos()))){
        setCursor(Qt::SizeBDiagCursor);//right top
        m_direction = StretchDirection::TopRight;
    }
    else if(QRect(SHADOW, rect().height() - SHADOW -SPACE/2,
                  SPACE/2, SPACE/2).contains(this->mapFromGlobal(event->globalPos()))){
        setCursor(Qt::SizeBDiagCursor);//left bottom
        m_direction = StretchDirection::BottomLeft;
    }
    else if(QRect(rect().width() - SHADOW - SPACE/2, rect().height() - SHADOW - SPACE/2,
                  SPACE/2, SPACE/2).contains(this->mapFromGlobal(event->globalPos()))){
        setCursor(Qt::SizeFDiagCursor);//right bottom
        m_direction = StretchDirection::BottomRight;
    }
    else {
        setCursor(Qt::ArrowCursor);//箭头
        m_direction = StretchDirection::None;
    }

#if 1
    //窗口拉伸
    if(m_mousePress && StretchDirection::None != m_direction){
        m_movePoint = event->globalPos() - (m_pressPoint - this->pos());
        m_pressPoint = event->globalPos();
        QRect rect = this->geometry();  //窗口原点

        switch (m_direction) {
        case StretchDirection::Left:
            rect.setLeft(m_movePoint.x());
            this->setGeometry(rect);
            break;
        case StretchDirection::Right:

            break;
        case StretchDirection::Up:

            break;
        case StretchDirection::Down:

            break;
        case StretchDirection::TopLeft:

            break;
        case StretchDirection::TopRight:

            break;
        case StretchDirection::BottomLeft:

            break;
        case StretchDirection::BottomRight:

            break;
        default:
            break;
        }
    }
#endif

    event->accept();
}

void MainInterface::enterEvent(QEvent *event)
{
    Q_UNUSED(event);
//    qDebug()<<"this->mapFromGlobal(QCursor::pos()) ="<<this->mapFromGlobal(QCursor::pos());
//    if(QRect(SHADOW, SHADOW + SPACE/2, SPACE/2, rect().height() - SPACE - 2*SHADOW).contains(this->mapFromGlobal(QCursor::pos()))){
//        setCursor(Qt::SizeHorCursor);//水平
//        qDebug()<<"1...";
//    }
//    else if(QRect(rect().width() - SHADOW - SPACE/2, SHADOW, SPACE/2, rect().height() - SPACE - 2*SHADOW).contains(this->mapFromGlobal(QCursor::pos()))){
//        setCursor(Qt::SizeHorCursor);//水平
//        qDebug()<<"2...";
//    }
//    else {
//        setCursor(Qt::ArrowCursor);//箭头
//    }
}

void MainInterface::leaveEvent(QEvent *event)
{
    Q_UNUSED(event);
}

void MainInterface::moveEvent(QMoveEvent *event)
{
    Q_UNUSED(event);

}

///////////////////// Event //////////////////////

void MainInterface::minimizeSlot()
{
    showMinimized();
}

void MainInterface::maximizeSlot()
{
    switch(m_fullScreenFlag){
        case 0:
        //showFullScreen();
        this->resize(1920 + 2*SHADOW, 1080 - 40 + 2*SHADOW);
        this->move(QPoint(-10, -10));
        m_fullScreenFlag++;
        m_pbMaximize->setStyleSheet("QPushButton{border-image:url(:/Images/fullscreen_exit_line.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                     "QPushButton:hover{border-image:url(:/Images/fullscreen_exit_line_2.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
        break;
    case 1:
        //showNormal();
        this->resize(WINDOW_W, WINDOW_H);
        this->move(QPoint((1920 - WINDOW_W)/2, (1080 - WINDOW_H)/2));
        m_fullScreenFlag--;
        m_pbMaximize->setStyleSheet("QPushButton{border-image:url(:/Images/fullscreen_line.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                     "QPushButton:hover{border-image:url(:/Images/fullscreen_line_3.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
        break;
    }
}

void MainInterface::closeSlot()
{
    close();
}

void MainInterface::playSlot()
{
    if(m_player->state() == QMediaPlayer::PlayingState) {
        m_pbPlay->setStyleSheet("QPushButton{border-image:url(:/Images/play_circle_fill.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
        m_player->pause();
    } else if(m_player->state() == QMediaPlayer::PausedState || m_player->state() == QMediaPlayer::StoppedState) {
        m_pbPlay->setStyleSheet("QPushButton{border-image:url(:/Images/pause_circle_fill.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
        m_player->play();
        qDebug()<<m_player->currentMedia().canonicalUrl();
    }
}

void MainInterface::nextSlot()
{
    int current = m_playlist->currentIndex();//获取当前位置
    if(++current > m_playlist->mediaCount()){
        current = 0;
    }
    m_playlist->setCurrentIndex(current);//设置当前音乐
    m_player->play();//播放
    qDebug()<<m_player->currentMedia().canonicalUrl();
}

void MainInterface::previousSlot()
{
    int current = m_playlist->currentIndex();//获取当前位置
    if(--current < 0){
        current = m_playlist->mediaCount() - 1;
    }

    m_playlist->setCurrentIndex(current);//设置当前音乐
    m_player->play();//播放
    qDebug()<<m_player->currentMedia().canonicalUrl();
}

void MainInterface::playModeSlot()
{
    MenuPlayMode *menuPlayMode = new MenuPlayMode();
#define Modal
#ifdef Modal
    /*模态对话框不需要指定父对象，因此坐标是相对于屏幕坐标*/
    menuPlayMode->setGeometry(QRect(pos().x() + m_pbPlayMode->geometry().x() - MENU_W/2, pos().y() + m_pbPlayMode->geometry().y() - MENU_H, MENU_W, MENU_H));
#else
    /*非模态对话框需要指定父对象，因此坐标是相对于软件窗口坐标*/
    menuPlayMode->setGeometry(QRect(m_pbPlayMode->geometry().x(), m_pbPlayMode->geometry().y() - MENU_H, MENU_W, MENU_H));
#endif
    //menuPlayMode->setText("弹窗测试中...");
    connect(menuPlayMode, &MenuPlayMode::shufflePlaySignal, this, &MainInterface::shufflePlaySlot);
    connect(menuPlayMode, &MenuPlayMode::orderPlaySignal, this, &MainInterface::orderPlaySlot);
    connect(menuPlayMode, &MenuPlayMode::repeatOnePlaySignal, this, &MainInterface::repeatOnePlaySlot);
    connect(menuPlayMode, &MenuPlayMode::repeatPlaySignal, this, &MainInterface::repeatPlaySlot);
    menuPlayMode->show();
}

void MainInterface::setVolumeSlot()
{
    DlgVolume *menuPlayMode = new DlgVolume();
#define Modal
#ifdef Modal
    /*模态对话框不需要指定父对象，因此坐标是相对于屏幕坐标*/
    menuPlayMode->setGeometry(QRect(pos().x() + m_pbVolume->geometry().x() - MENU_W/4, pos().y() + m_pbVolume->geometry().y() - MENU_H - 60, MENU_W/2, MENU_H + 60));
#else
    /*非模态对话框需要指定父对象，因此坐标是相对于软件窗口坐标*/
    menuPlayMode->setGeometry(QRect(m_pbPlayMode->geometry().x(), m_pbPlayMode->geometry().y() - MENU_H, MENU_W, MENU_H));
#endif
    //menuPlayMode->setText("弹窗测试中...");
//    connect(menuPlayMode, &MenuPlayMode::shufflePlaySignal, this, &MainInterface::shufflePlaySlot);
//    connect(menuPlayMode, &MenuPlayMode::orderPlaySignal, this, &MainInterface::orderPlaySlot);
//    connect(menuPlayMode, &MenuPlayMode::repeatOnePlaySignal, this, &MainInterface::repeatOnePlaySlot);
//    connect(menuPlayMode, &MenuPlayMode::repeatPlaySignal, this, &MainInterface::repeatPlaySlot);
    menuPlayMode->show();
}

void MainInterface::favoriteSlot()
{

}

void MainInterface::localMusicSlot()
{

}

void MainInterface::recentPlaySLot()
{

}

void MainInterface::changeSkinSlot()
{

}

void MainInterface::checkScreenSlot()
{
    if(!isFullScreen()){
        QScreen * screen =  QGuiApplication::primaryScreen();
        QRect rect = screen->geometry();
        int desktop_width = rect.width();
        int desktop_height = rect.height();
        //qDebug() << desktop_width <<desktop_height;

        //计算横向纵向坐标的伸缩系统
        double factorx = desktop_width / 1920.0;  //1920 是开发电脑界面的分辨率
        double factory = desktop_height / 1080.0;
        if((int)m_factorx != factorx || (int)m_factory != factory){
            this->resize(WINDOW_W * factorx, WINDOW_H * factory);
            m_factorx = factorx;
            m_factory = factory;
            update();
        }
    }
}

void MainInterface::serachSlot()
{
    QString word = m_leSerach->text();
    m_networkAccessManager =new QNetworkAccessManager();
    if (word != "") {
        qDebug() << word;
        QString surl = "http://c.y.qq.com/soso/fcgi-bin/client_search_cp?t=0&aggr=1&lossless=1&cr=1&catZhida=1&format=json&p=1&n=40&w=" + word;
        qDebug() <<  surl;
        QUrl url = QString(surl);
        QNetworkReply *reply;
        reply = m_networkAccessManager->get(QNetworkRequest(url));
        QEventLoop loop;
        connect(reply, SIGNAL(finished()), &loop, SLOT(quit()));
        loop.exec();
        QByteArray BA = reply->readAll();

        QJsonDocument json = QJsonDocument::fromJson(BA);
        QJsonArray list = json.object().value("data").toObject().value("song").toObject().value("list").toArray();
 //       ui->tableWidget->setRowCount(0);
        QStringList header;
        header<<"歌名"<<"歌手";

//        ui->tableWidget->setHorizontalHeaderLabels(header);

          for (int i = 0; i < list.size(); i++) {
            qDebug()<<list[i].toObject().value("songname").toString()
                   <<list[i].toObject().value("singer").toArray()[0].toObject().value("name").toString()
                  <<list[i].toObject().value("songmid").toString()
                 <<list[i].toObject().value("albummid").toString();
//            ui->tableWidget->insertRow(i);
//            ui->tableWidget->setItem(i,0,new QTableWidgetItem(list[i].toObject().value("songname").toString()));
//            ui->tableWidget->setItem(i,1,new QTableWidgetItem(list[i].toObject().value("singer").toArray()[0].toObject().value("name").toString()));
//            ui->tableWidget->setItem(i,2,new QTableWidgetItem(list[i].toObject().value("songmid").toString()));
//            ui->tableWidget->setItem(i,3,new QTableWidgetItem(list[i].toObject().value("albummid").toString()));
          }

//        ui->tableWidget->resizeColumnsToContents();
//        ui->tableWidget->scrollToTop();
    }
}

void MainInterface::shufflePlaySlot()
{
    m_pbPlayMode->setStyleSheet("QPushButton{border-image:url(:/Images/shuffle_line_1.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/shuffle_line_3.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
}

void MainInterface::orderPlaySlot()
{
    m_pbPlayMode->setStyleSheet("QPushButton{border-image:url(:/Images/order_play_line_2.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/order_play_line.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
}

void MainInterface::repeatOnePlaySlot()
{
    m_pbPlayMode->setStyleSheet("QPushButton{border-image:url(:/Images/repeat_one_line.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/repeat_one_line_2.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
}

void MainInterface::repeatPlaySlot()
{
    m_pbPlayMode->setStyleSheet("QPushButton{border-image:url(:/Images/repeat_2_line.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/repeat_2_line_2.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
}
