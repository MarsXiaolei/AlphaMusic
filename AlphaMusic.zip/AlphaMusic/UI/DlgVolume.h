﻿#ifndef DLGVOLUME_H
#define DLGVOLUME_H

#include <QWidget>
#include <QGraphicsDropShadowEffect>
#include <QPainter>
#include <QPushButton>
#include <QEvent>
#include <QApplication>
#include <QSlider>
#include <QVBoxLayout>
#include <QLabel>

class DlgVolume : public QWidget
{
    Q_OBJECT
public:
    explicit DlgVolume(QWidget *parent = nullptr);

signals:

public slots:

protected:
    virtual void paintEvent(QPaintEvent *event);

private:
    QSlider *m_sliderVolume;
    QLabel *m_labelVolume;
    QPushButton *m_pbVolume;
};

#endif // DLGVOLUME_H
