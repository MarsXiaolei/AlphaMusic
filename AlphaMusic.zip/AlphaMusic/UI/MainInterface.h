﻿#ifndef MAININTERFACE_H
#define MAININTERFACE_H

#include <QWidget>
#include <QPaintEvent>
#include <QMouseEvent>
#include <QEvent>
#include <QMoveEvent>
#include <QPoint>
#include <QPainter>
#include <QGraphicsDropShadowEffect>
#include <QTextOption>
#include <QImage>
#include <QPushButton>
#include <QHBoxLayout>
#include <QLabel>
#include <QScreen>
#include <QTimer>
#include <QSlider>
#include <QStackedWidget>
#include <QLineEdit>

#include <QMediaPlayer>
#include <QMediaPlaylist>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>

#include "MenuPlayMode.h"
#include "WidgetLocalMusic.h"
#include "DlgVolume.h"

namespace Ui {
class MainInterface;
}

class MainInterface : public QWidget
{
    Q_OBJECT

public:
    explicit MainInterface(QWidget *parent = nullptr);
    ~MainInterface();
    enum PlayState{
        Play = 0,
        Pause
    };

    enum StretchDirection{
        None = 0x00,
        Left,
        Right,
        Up,
        Down,
        TopLeft,
        TopRight,
        BottomLeft,
        BottomRight
    };

signals:

protected:
    virtual void paintEvent(QPaintEvent *event);
    virtual void mousePressEvent(QMouseEvent *event);
    virtual void mouseReleaseEvent(QMouseEvent *event);
    virtual void mouseDoubleClickEvent(QMouseEvent *event);
    virtual void mouseMoveEvent(QMouseEvent *event);
    virtual void enterEvent(QEvent *event);
    virtual void leaveEvent(QEvent *event);
    virtual void moveEvent(QMoveEvent *event);

    virtual bool event(QEvent *event);
private slots:
    //最小化
    void minimizeSlot();

    //最大化
    void maximizeSlot();

    //关闭窗口
    void closeSlot();

    //播放
    void playSlot();

    //下一首
    void nextSlot();

    //上一首
    void previousSlot();

    //播放模式
    void playModeSlot();

    //设置音量
    void setVolumeSlot();

    //我喜欢
    void favoriteSlot();

    //本地
    void localMusicSlot();

    //最近播放
    void recentPlaySLot();

    //换肤
    void changeSkinSlot();

    //检测分辨率
    void checkScreenSlot();

    void serachSlot();


    void shufflePlaySlot();
    void orderPlaySlot();
    void repeatOnePlaySlot();
    void repeatPlaySlot();
private:
    Ui::MainInterface *ui;

    /*********** UI ***************/
    QPushButton *m_pbMinimize;
    QPushButton *m_pbMaximize;
    QPushButton *m_pbClose;
    QPushButton *m_pbSkin;
    QPushButton *m_pbMainMenu;
    QLineEdit *m_leSerach;
    QPushButton *m_pbSerach;

    QLabel *m_labelMusicPoster;
    QLabel *m_labelMusicName;
    QPushButton *m_pbAddFavorite;
    QPushButton *m_pbDownload;

    QPushButton *m_pbPlay;
    QPushButton *m_pbPrevious;
    QPushButton *m_pbNext;
    QPushButton *m_pbPlayMode;
    QPushButton *m_pbVolume;

    QLabel *m_labelPlayTime;//播放时间
    QString m_playTime;
    QPushButton *m_pbLyrics;//歌词
    QPushButton *m_pbPlayQueue;//播放队列

    QSlider *m_sliderPlay;
    QStackedWidget *m_stackedWidget;

    QPushButton *m_onlineMusic_1;
    QPushButton *m_onlineMusic_2;
    QPushButton *m_onlineMusic_3;
    QPushButton *m_onlineMusic_4;

    QPushButton *m_localMusic_1;
    QPushButton *m_localMusic_2;
    QPushButton *m_localMusic_3;
    QPushButton *m_localMusic_4;
    //////////// UI //////////

    bool m_mousePress;
    QPoint m_pressPoint;
    QPoint m_movePoint;


    QMediaPlayer *m_player;
    QMediaPlaylist *m_playlist;
    PlayState m_playState;

    QTimer *m_timer;
    double m_factorx;  //1920 是开发电脑界面的分辨率
    double m_factory;
    bool m_resizeFlag;

    int m_fullScreenFlag;

    QNetworkAccessManager *m_networkAccessManager;

    StretchDirection m_direction;
};

#endif // MAININTERFACE_H
