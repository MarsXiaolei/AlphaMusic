﻿#ifndef MENUPLAYMODE_H
#define MENUPLAYMODE_H

#include <QWidget>
#include <QGraphicsDropShadowEffect>
#include <QPainter>
#include <QPushButton>
#include <QEvent>
#include <QApplication>

class MenuPlayMode : public QWidget
{
    Q_OBJECT
public:
    explicit MenuPlayMode(QWidget *parent = nullptr);

signals:
    void shufflePlaySignal();
    void orderPlaySignal();
    void repeatOnePlaySignal();
    void repeatPlaySignal();

public slots:

protected:
    virtual void paintEvent(QPaintEvent *event);

private slots:
    //随机播放
    void shufflePlaySlot();
    //顺序播放
    void orderPlaySlot();
    //单曲循环
    void repeatOnePlaySlot();
    //列表循环
    void repeatPlaySlot();

private:
    QPushButton *m_pbShufflePlay;
    QPushButton *m_pbOrderPlay;
    QPushButton *m_pbRepeatOnePlay;
    QPushButton *m_pbRepeatPlay;
};

#endif // MENUPLAYMODE_H
