﻿#ifndef MYLISTITEM_H
#define MYLISTITEM_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QHBoxLayout>
#include <QPainter>
#include <QMouseEvent>
#include <QPushButton>
#include <QGridLayout>
#include <QSpacerItem>

class MyListItem : public QWidget
{
    Q_OBJECT
public:
    explicit MyListItem(QWidget *parent = nullptr);

signals:

public slots:

protected:

private slots:
    void heartSlot();

private:
     QPushButton *m_pbHeart;
     int m_heartFlag;
};

#endif // MYLISTITEM_H
