#ifndef WIDGETRECENTPLAY_H
#define WIDGETRECENTPLAY_H

#include <QWidget>

class WidgetRecentPlay : public QWidget
{
    Q_OBJECT
public:
    explicit WidgetRecentPlay(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // WIDGETRECENTPLAY_H