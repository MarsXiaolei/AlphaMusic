﻿#ifndef WIDGETLOCALMUSIC_H
#define WIDGETLOCALMUSIC_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QHBoxLayout>
#include <QListWidgetItem>
#include <QListWidget>
#include <QScrollBar>
#include <QAbstractSlider>

#include "MyListItem.h"


class WidgetLocalMusic : public QWidget
{
    Q_OBJECT
public:
    explicit WidgetLocalMusic(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // WIDGETLOCALMUSIC_H
