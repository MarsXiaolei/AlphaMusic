﻿#include "DlgVolume.h"
#include "Module/Global.h"
#include <QDebug>

DlgVolume::DlgVolume(QWidget *parent) : QWidget(parent)
{
    //设置窗口无边框
    setWindowFlags(Qt::FramelessWindowHint);
    //设置窗体透明,防止边距显示不同的颜色
    setAttribute(Qt::WA_TranslucentBackground, true);
    setWindowModality(Qt::ApplicationModal);//设置窗体模态，要求该窗体没有父类，否则无效

    //实例阴影shadow（注意：设置无边框后，需要给阴影绘制预留尺寸，不能完全填充）
    QGraphicsDropShadowEffect *shadow = new QGraphicsDropShadowEffect(this);
    shadow->setOffset(0, 0);
    //边框阴影颜色最好和背景色一样，容易产生渐变
    shadow->setColor("#2f89fc");
    shadow->setBlurRadius(SHADOW);
    setGraphicsEffect(shadow);

    QVBoxLayout *verticalLayout_2;
    verticalLayout_2 = new QVBoxLayout(this);
    verticalLayout_2->setSpacing(SPACE);
    verticalLayout_2->setContentsMargins((MENU_W/2 - PB_W)/2, 2*SHADOW, (MENU_W/2 - PB_W)/2, 2*SHADOW);

    //播放滑动条
    m_sliderVolume = new QSlider(this);
    m_sliderVolume->setOrientation(Qt::Vertical);
    m_sliderVolume->setStyleSheet(g_styleSheet);
    m_sliderVolume->setMinimumWidth(PB_W);
    //gridLayout->addWidget(m_sliderVolume, 2, 1, 1, 1);

    m_labelVolume = new QLabel(this);
    m_labelVolume->setText("70%");
    m_labelVolume->setMinimumSize(QSize(PB_W, PB_H_2));
    m_labelVolume->setMaximumSize(QSize(PB_W, PB_H_2));
    m_labelVolume->setStyleSheet(g_styleSheet);
    m_labelVolume->setAlignment(Qt::AlignCenter);

    //音量
    m_pbVolume = new QPushButton(this);
    m_pbVolume->setFocusPolicy(Qt::NoFocus);
    m_pbVolume->setStyleSheet("QPushButton{border-image:url(:/Images/volume_up_fill.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/volume_up_fill_3.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
    //connect(m_pbVolume, &QPushButton::clicked, this, &MainInterface::playModeSlot);
    m_pbVolume->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbVolume->setMaximumSize(QSize(PB_W_2, PB_H_2));

    verticalLayout_2->addWidget(m_sliderVolume, 0, Qt::AlignHCenter);
    verticalLayout_2->addWidget(m_labelVolume);
    verticalLayout_2->addWidget(m_pbVolume, 0, Qt::AlignHCenter);
}

void DlgVolume::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    //区域填充颜色
    QPainter painter(this);
    painter.setRenderHint(QPainter::SmoothPixmapTransform);
    QPainterPath path;
    path.addRoundedRect(QRect(rect().x() + SHADOW, rect().y() + SHADOW, rect().width() - SHADOW * 2, rect().height() - SHADOW * 2), 5, 5);
    painter.setClipPath(path);//设置圆角
    QRect titleRect(QRect(rect().x() + SHADOW, rect().y() + SHADOW, rect().width() - SHADOW * 2, rect().height() - SHADOW * 2));
    QColor paintColor = QColor("#FFFFFF");
    painter.fillRect(titleRect, paintColor);


    paintColor = QColor("#999999");
    painter.setPen(paintColor);

    QLine line_1(SHADOW + SPACE/4, 4*(rect().height() - 2*SHADOW)/5 + 3*SHADOW/2,
                 rect().width() - SHADOW - SPACE/4, 4*(rect().height() - 2*SHADOW)/5 + 3*SHADOW/2);

    painter.drawLine(line_1);
#if 0
    QLine line_2(SHADOW + SPACE/4, SHADOW + 2*(rect().height() - 2*SHADOW)/4,
                 rect().width() - SHADOW - SPACE/4, SHADOW + 2*(rect().height() - 2*SHADOW)/4);
    painter.drawLine(line_2);
    QLine line_3(SHADOW + SPACE/4, SHADOW + 3*(rect().height() - 2*SHADOW)/4,
                 rect().width() - SHADOW - SPACE/4, SHADOW + 3*(rect().height() - 2*SHADOW)/4);
    painter.drawLine(line_3);
#endif
}
