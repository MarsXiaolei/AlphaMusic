﻿#include "MyListItem.h"
#include "Module/Global.h"
#include <QDebug>

MyListItem::MyListItem(QWidget *parent) : QWidget(parent)
{
    m_heartFlag = 0;

    m_pbHeart = new QPushButton(this);
    //pbHeart->setFocusPolicy(Qt::NoFocus);
    //pbHeart->setGeometry(QRect(WINDOW_W - SHADOW - (SPACE + PB_W), (TITLE_H - PB_H)/2 + SHADOW, PB_W, PB_H));
    m_pbHeart->setStyleSheet("QPushButton{border-image:url(:/Images/heart_fill_1.png);border-width:0px;border-style:solid}"
                                 "QPushButton:hover{border-image:url(:/Images/heart_fill_3.png);border-width:0px;border-style:solid}");
    connect(m_pbHeart, &QPushButton::clicked, this, &MyListItem::heartSlot);
    m_pbHeart->setMinimumSize(QSize(PB_W_2, PB_H_2));
    m_pbHeart->setMaximumSize(QSize(PB_W_2, PB_H_2));

    QString labelStyle = "QLabel{font-family:Microsoft YaHei;font-size: 10pt;color: #1dcf9d;/*background-color: #1dcf9d;*}";
    QLabel *m_labelMusicName = new QLabel(this);
    m_labelMusicName->setText("在线音乐-往事随风");
    m_labelMusicName->setMinimumSize(QSize(120, PB_H_2));
    m_labelMusicName->setMaximumSize(QSize(120, PB_H_2));
    m_labelMusicName->setStyleSheet(labelStyle);

    QLabel *m_labelMusicName_2 = new QLabel(this);
    m_labelMusicName_2->setText("许嵩");
    m_labelMusicName_2->setMinimumSize(QSize(120, PB_H_2));
    m_labelMusicName_2->setMaximumSize(QSize(120, PB_H_2));
    m_labelMusicName_2->setStyleSheet(labelStyle);

    QLabel *m_labelMusicName_3 = new QLabel(this);
    m_labelMusicName_3->setText("");
    m_labelMusicName_3->setMinimumSize(QSize(120, PB_H_2));
    m_labelMusicName_3->setMaximumSize(QSize(120, PB_H_2));
    m_labelMusicName_3->setStyleSheet(labelStyle);

    QLabel *m_labelMusicName_4 = new QLabel(this);
    m_labelMusicName_4->setText("");
    m_labelMusicName_4->setMinimumSize(QSize(120, PB_H_2));
    m_labelMusicName_4->setMaximumSize(QSize(120, PB_H_2));
    m_labelMusicName_4->setStyleSheet(labelStyle);

    QHBoxLayout *horLayout_2 = new QHBoxLayout;
    horLayout_2->setContentsMargins(0, 0, 0, 0);
    horLayout_2->setSpacing(SPACE);
    horLayout_2->addWidget(m_pbHeart);
    horLayout_2->addWidget(m_labelMusicName);

    QHBoxLayout *horLayout = new QHBoxLayout;
    horLayout->setContentsMargins(SPACE, 0, SPACE, 0);
    horLayout->setAlignment(Qt::AlignLeft);
    horLayout->setSpacing(SPACE);
    horLayout->addLayout(horLayout_2);
    QSpacerItem *horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
    horLayout->addItem(horizontalSpacer);
    horLayout->addWidget(m_labelMusicName_2);
    QSpacerItem *horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
    horLayout->addItem(horizontalSpacer_2);
    horLayout->addWidget(m_labelMusicName_3);
    QSpacerItem *horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
    horLayout->addItem(horizontalSpacer_3);
    horLayout->addWidget(m_labelMusicName_4);
    QSpacerItem *horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
    horLayout->addItem(horizontalSpacer_4);

//    QGridLayout *gridLayout = new QGridLayout(this);
//    gridLayout->setSpacing(6);
//    gridLayout->setContentsMargins(0, 0, 0, 0);
    this->setLayout(horLayout);
}

void MyListItem::heartSlot()
{
    switch (m_heartFlag) {
    case 0:
        m_pbHeart->setStyleSheet("QPushButton{border-image:url(:/Images/heart_fill_2.png);border-top-right-radius:10;border-width:0px;border-style:solid}"
                                    "QPushButton:hover{border-image:url(:/Images/heart_fill_2.png);border-top-right-radius:10;border-width:0px;border-style:solid}");
        m_heartFlag++;
        break;
    case 1:
        m_pbHeart->setStyleSheet("QPushButton{border-image:url(:/Images/heart_fill_1.png);border-width:0px;border-style:solid}"
                                     "QPushButton:hover{border-image:url(:/Images/heart_fill_3.png);border-width:0px;border-style:solid}");
        m_heartFlag--;
        break;
    default:
        break;
    }
    qDebug()<<"MyListItem::heartSlot...";
}
