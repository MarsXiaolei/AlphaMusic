﻿#include "MenuPlayMode.h"
#include "Module/Global.h"
#include <QDebug>

MenuPlayMode::MenuPlayMode(QWidget *parent) : QWidget(parent)
{
    //设置窗口无边框
    setWindowFlags(Qt::FramelessWindowHint);
    //设置窗体透明,防止边距显示不同的颜色
    setAttribute(Qt::WA_TranslucentBackground, true);
    setWindowModality(Qt::ApplicationModal);//设置窗体模态，要求该窗体没有父类，否则无效

    //实例阴影shadow（注意：设置无边框后，需要给阴影绘制预留尺寸，不能完全填充）
    QGraphicsDropShadowEffect *shadow = new QGraphicsDropShadowEffect(this);
    shadow->setOffset(0, 0);
    //边框阴影颜色最好和背景色一样，容易产生渐变
    shadow->setColor("#2f89fc");
    shadow->setBlurRadius(SHADOW);
    setGraphicsEffect(shadow);

    setFocusPolicy(Qt::ClickFocus);

    QString styleSheet = "QPushButton{font: 10pt 微软雅黑;"
                         "color: #333333;"
                         "background-color:#FFFFFF;"
                         "border-style: solid;"
                         "border-width: 0px;"
                         "border-color: #FFFFFF;}"
                         "QPushButton:hover{color: #333333;"
                         "background-color: #EEEEEE;"
                         "border-color: #FFFFFF;}";

    m_pbShufflePlay = new QPushButton(this);
    //m_pbShufflePlay->setFocusPolicy(Qt::NoFocus);
    m_pbShufflePlay->setGeometry(QRect(SHADOW + SPACE/4, SHADOW + 0*((MENU_H - 2*SHADOW)/4) + SPACE/4,
                                       MENU_W - 2*SHADOW - SPACE/2, (MENU_H - 2*SHADOW)/4 - SPACE/2));
    m_pbShufflePlay->setText("随机播放");
    m_pbShufflePlay->setStyleSheet(styleSheet);
    connect(m_pbShufflePlay, &QPushButton::clicked, this, &MenuPlayMode::shufflePlaySlot);

    m_pbOrderPlay = new QPushButton(this);
    //m_pbOrderPlay->setFocusPolicy(Qt::NoFocus);
    m_pbOrderPlay->setGeometry(QRect(SHADOW + SPACE/4, SHADOW + 1*(MENU_H - 2*SHADOW)/4 + SPACE/4,
                                       MENU_W - 2*SHADOW - SPACE/2, (MENU_H - 2*SHADOW)/4 - SPACE/2));
    m_pbOrderPlay->setText("顺序播放");
    m_pbOrderPlay->setStyleSheet(styleSheet);
    connect(m_pbOrderPlay, &QPushButton::clicked, this, &MenuPlayMode::orderPlaySlot);

    m_pbRepeatOnePlay = new QPushButton(this);
    //m_pbRepeatOnePlay->setFocusPolicy(Qt::NoFocus);
    m_pbRepeatOnePlay->setGeometry(QRect(SHADOW + SPACE/4, SHADOW + 2*(MENU_H - 2*SHADOW)/4 + SPACE/4,
                                       MENU_W - 2*SHADOW - SPACE/2, (MENU_H - 2*SHADOW)/4 - SPACE/2));
    m_pbRepeatOnePlay->setText("单曲循环");
    m_pbRepeatOnePlay->setStyleSheet(styleSheet);
    connect(m_pbRepeatOnePlay, &QPushButton::clicked, this, &MenuPlayMode::repeatOnePlaySlot);

    m_pbRepeatPlay = new QPushButton(this);
    //m_pbRepeatPlay->setFocusPolicy(Qt::NoFocus);
    m_pbRepeatPlay->setGeometry(QRect(SHADOW + SPACE/4, SHADOW + 3*(MENU_H - 2*SHADOW)/4 + SPACE/4,
                                       MENU_W - 2*SHADOW - SPACE/2, (MENU_H - 2*SHADOW)/4 - SPACE/2));
    m_pbRepeatPlay->setText("列表循环");
    m_pbRepeatPlay->setStyleSheet(styleSheet);
    connect(m_pbRepeatPlay, &QPushButton::clicked, this, &MenuPlayMode::repeatPlaySlot);

    activateWindow();


    //安装过滤器
    //installEventFilter(this);
}

void MenuPlayMode::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    //区域填充颜色
    QPainter painter(this);
    painter.setRenderHint(QPainter::SmoothPixmapTransform);
    QPainterPath path;
    path.addRoundedRect(QRect(rect().x() + SHADOW, rect().y() + SHADOW, rect().width() - SHADOW * 2, rect().height() - SHADOW * 2), 5, 5);
    painter.setClipPath(path);//设置圆角
    QRect titleRect(QRect(rect().x() + SHADOW, rect().y() + SHADOW, rect().width() - SHADOW * 2, rect().height() - SHADOW * 2));
    QColor paintColor = QColor("#FFFFFF");
    painter.fillRect(titleRect, paintColor);

    paintColor = QColor("#999999");
    painter.setPen(paintColor);
    QLine line_1(SHADOW + SPACE/4, SHADOW + 1*(rect().height() - 2*SHADOW)/4,
                 rect().width() - SHADOW - SPACE/4, SHADOW + 1*(rect().height() - 2*SHADOW)/4);
    painter.drawLine(line_1);
    QLine line_2(SHADOW + SPACE/4, SHADOW + 2*(rect().height() - 2*SHADOW)/4,
                 rect().width() - SHADOW - SPACE/4, SHADOW + 2*(rect().height() - 2*SHADOW)/4);
    painter.drawLine(line_2);
    QLine line_3(SHADOW + SPACE/4, SHADOW + 3*(rect().height() - 2*SHADOW)/4,
                 rect().width() - SHADOW - SPACE/4, SHADOW + 3*(rect().height() - 2*SHADOW)/4);
    painter.drawLine(line_3);
}

void MenuPlayMode::shufflePlaySlot()
{
    emit shufflePlaySignal();
    close();
}

void MenuPlayMode::orderPlaySlot()
{
    emit orderPlaySignal();
    close();
}

void MenuPlayMode::repeatOnePlaySlot()
{
    emit repeatOnePlaySignal();
    close();
}

void MenuPlayMode::repeatPlaySlot()
{
    emit repeatPlaySignal();
    close();
}

