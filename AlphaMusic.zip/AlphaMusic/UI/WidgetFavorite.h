#ifndef WIDGETFAVORITE_H
#define WIDGETFAVORITE_H

#include <QWidget>

class WidgetFavorite : public QWidget
{
    Q_OBJECT
public:
    explicit WidgetFavorite(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // WIDGETFAVORITE_H