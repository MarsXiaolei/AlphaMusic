﻿#include "MainInterface.h"
#include <QApplication>
#include "Module/Global.h"
#include <QFile>
#include <QObject>

QString g_styleSheet;

//////////防止软件多次开启////////
#if defined Q_OS_WIN32   //for win
#include <windows.h>
bool checkOnly()
{
    //  创建互斥量
    HANDLE m_hMutex  =  CreateMutex(NULL, FALSE,  L"YYDS" );
    //  检查错误代码
    if  (GetLastError()  ==  ERROR_ALREADY_EXISTS)  {
      //  如果已有互斥量存在则释放句柄并复位互斥量
     CloseHandle(m_hMutex);
     m_hMutex  =  NULL;
      //  程序退出
      return  false;
    }
    else
        return true;
}
#endif
#if defined  Q_OS_LINUX   //for linux
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
bool checkOnly()
{
    const char filename[]  = "/tmp/lockfile";
    int fd = open (filename, O_WRONLY | O_CREAT , 0644);
    int flock = lockf(fd, F_TLOCK, 0 );
    if (fd == -1) {
            perror("open lockfile/n");
            return false;
    }
    //给文件加锁
    if (flock == -1) {
            perror("lock file error/n");
            return false;
    }
    //程序退出后，文件自动解锁
    return true;
}
#endif

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    //检查程序是否 已经启动过
    if(false == checkOnly()){
        return 0;
    }

    /*************读取样式表*****************/
    QFile file(":/qss/StyleSheet.qss");
    //只读方式打开文件
    file.open(QFile::ReadOnly);
    //读取文件的所有内容，并转换成QString类型
    g_styleSheet = QObject::tr(file.readAll());

    MainInterface w;

    //new add code

    w.show();

    return a.exec();
}
