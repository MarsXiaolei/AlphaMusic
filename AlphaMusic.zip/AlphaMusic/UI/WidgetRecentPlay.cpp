#include "WidgetRecentPlay.h"

WidgetRecentPlay::WidgetRecentPlay(QWidget *parent) : QWidget(parent)
{

}
