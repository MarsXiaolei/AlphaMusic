#include "WidgetFavorite.h"

WidgetFavorite::WidgetFavorite(QWidget *parent) : QWidget(parent)
{

}
