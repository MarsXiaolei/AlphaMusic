﻿#ifndef GLOBAL_H
#define GLOBAL_H

#define VERSION "V0.0.1"

#define SCREEN_W    1920
#define SCREEN_H    1080

#define SHADOW  10

#define WINDOW_W    (1200 + 2*SHADOW)
#define WINDOW_H    (800 + 2*SHADOW)

#define TITLE_W     WINDOW_W
#define TITLE_H     70

#define PB_W    32
#define PB_H    PB_W

#define PB_W_2    24
#define PB_H_2    PB_W_2

#define PB_W_3    132
#define PB_H_3    30

#define SPACE   12

#define MENU_W  120
#define MENU_H  180

//解决中文乱码
#if _MSC_VER >= 1600
#pragma execution_character_set("utf-8")
#endif

#include <QString>
extern QString g_styleSheet;

#endif // GLOBAL_H
