/****************************************************************************
** Meta object code from reading C++ file 'MainInterface.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../UI/MainInterface.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MainInterface.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainInterface_t {
    QByteArrayData data[20];
    char stringdata0[257];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainInterface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainInterface_t qt_meta_stringdata_MainInterface = {
    {
QT_MOC_LITERAL(0, 0, 13), // "MainInterface"
QT_MOC_LITERAL(1, 14, 12), // "minimizeSlot"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 12), // "maximizeSlot"
QT_MOC_LITERAL(4, 41, 9), // "closeSlot"
QT_MOC_LITERAL(5, 51, 8), // "playSlot"
QT_MOC_LITERAL(6, 60, 8), // "nextSlot"
QT_MOC_LITERAL(7, 69, 12), // "previousSlot"
QT_MOC_LITERAL(8, 82, 12), // "playModeSlot"
QT_MOC_LITERAL(9, 95, 13), // "setVolumeSlot"
QT_MOC_LITERAL(10, 109, 12), // "favoriteSlot"
QT_MOC_LITERAL(11, 122, 14), // "localMusicSlot"
QT_MOC_LITERAL(12, 137, 14), // "recentPlaySLot"
QT_MOC_LITERAL(13, 152, 14), // "changeSkinSlot"
QT_MOC_LITERAL(14, 167, 15), // "checkScreenSlot"
QT_MOC_LITERAL(15, 183, 10), // "serachSlot"
QT_MOC_LITERAL(16, 194, 15), // "shufflePlaySlot"
QT_MOC_LITERAL(17, 210, 13), // "orderPlaySlot"
QT_MOC_LITERAL(18, 224, 17), // "repeatOnePlaySlot"
QT_MOC_LITERAL(19, 242, 14) // "repeatPlaySlot"

    },
    "MainInterface\0minimizeSlot\0\0maximizeSlot\0"
    "closeSlot\0playSlot\0nextSlot\0previousSlot\0"
    "playModeSlot\0setVolumeSlot\0favoriteSlot\0"
    "localMusicSlot\0recentPlaySLot\0"
    "changeSkinSlot\0checkScreenSlot\0"
    "serachSlot\0shufflePlaySlot\0orderPlaySlot\0"
    "repeatOnePlaySlot\0repeatPlaySlot"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainInterface[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  104,    2, 0x08 /* Private */,
       3,    0,  105,    2, 0x08 /* Private */,
       4,    0,  106,    2, 0x08 /* Private */,
       5,    0,  107,    2, 0x08 /* Private */,
       6,    0,  108,    2, 0x08 /* Private */,
       7,    0,  109,    2, 0x08 /* Private */,
       8,    0,  110,    2, 0x08 /* Private */,
       9,    0,  111,    2, 0x08 /* Private */,
      10,    0,  112,    2, 0x08 /* Private */,
      11,    0,  113,    2, 0x08 /* Private */,
      12,    0,  114,    2, 0x08 /* Private */,
      13,    0,  115,    2, 0x08 /* Private */,
      14,    0,  116,    2, 0x08 /* Private */,
      15,    0,  117,    2, 0x08 /* Private */,
      16,    0,  118,    2, 0x08 /* Private */,
      17,    0,  119,    2, 0x08 /* Private */,
      18,    0,  120,    2, 0x08 /* Private */,
      19,    0,  121,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainInterface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainInterface *_t = static_cast<MainInterface *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->minimizeSlot(); break;
        case 1: _t->maximizeSlot(); break;
        case 2: _t->closeSlot(); break;
        case 3: _t->playSlot(); break;
        case 4: _t->nextSlot(); break;
        case 5: _t->previousSlot(); break;
        case 6: _t->playModeSlot(); break;
        case 7: _t->setVolumeSlot(); break;
        case 8: _t->favoriteSlot(); break;
        case 9: _t->localMusicSlot(); break;
        case 10: _t->recentPlaySLot(); break;
        case 11: _t->changeSkinSlot(); break;
        case 12: _t->checkScreenSlot(); break;
        case 13: _t->serachSlot(); break;
        case 14: _t->shufflePlaySlot(); break;
        case 15: _t->orderPlaySlot(); break;
        case 16: _t->repeatOnePlaySlot(); break;
        case 17: _t->repeatPlaySlot(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject MainInterface::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_MainInterface.data,
    qt_meta_data_MainInterface,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainInterface.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int MainInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
